<?php
   // define database related variables
   $database = 'ice-n-spice';
   $host = 'localhost';
   $user = 'root@localhost';
   $pass = '';

   // try to conncet to database
   $dbh = new PDO("mysql:dbname={$database};host={$host}", $user, $pass);
  // $dbh = mysqli_connect ($host,$user,$pass,$database);
   if(!$dbh){

      echo "unable to connect to database";
   }
else 
{echo "database successfully connected!!!";
}

//mysql_select_db("ice-n-spice", $con);
   
?>