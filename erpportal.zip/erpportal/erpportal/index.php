<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>IceNSpice</title>
    <link rel="shortcut icon" href="img/logo.jpg"/>
    <!-- Bootstrap Core CSS - Uses Bootswatch Flatly Theme: http://bootswatch.com/flatly/ -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/freelancer.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top" class="index">
<?php
session_start();

?>  
    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#page-top">Home</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li class="page-scroll">
                        <a href="#portfolio">Menu</a>
                    </li>
                    <li class="page-scroll">
                        <a href="#about
						
						
						
						">About</a>
                    </li>
                    <li class="page-scroll">
                        <a href="#contact">Contact</a>
                    </li>
                    <?php
			if(isset($_SESSION['username']))
			{?>
			 <li style="float:right"><a href="logout.php"><?php echo '<font face="verdana" color="yellow">'.$_SESSION['username'].'</font>';?> Logout</a></li>
			<?php
			}
			else
			{?>
			<li style="float:right"><a href="login1.php">LOGIN</a></li>
			<?php
			}
			?>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <!-- Header -->
    <header>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <img class="img-responsive" src="img/logo.jpg" alt="">
                    <div class="intro-text">
                        <span class="name">ICE n SPICE</span>
                        <hr class="star-light">
                        <span class="skills">A Global Leader in Food & Beverages</span>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Portfolio Grid Section -->
    <section id="portfolio">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2> </h2>
                    <hr class="star-primary">
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4 portfolio-item">
                    <a href="#portfolioModal1" class="portfolio-link" data-toggle="modal">
                        <div class="caption">
                            <div class="caption-content">
                                <i class="fa fa-search-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="img/portfolio/cabin.png" class="img-responsive" alt="">
                    </a>
                </div>
                <div class="col-sm-4 portfolio-item">
                    <a href="#portfolioModal2" class="portfolio-link" data-toggle="modal">
                        <div class="caption">
                            <div class="caption-content">
                                <i class="fa fa-search-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="img/portfolio/cake.png" class="img-responsive" alt="">
                    </a>
                </div>
                <div class="col-sm-4 portfolio-item">
                    <a href="#portfolioModal3" class="portfolio-link" data-toggle="modal">
                        <div class="caption">
                            <div class="caption-content">
                                <i class="fa fa-search-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="img/portfolio/circus.png" class="img-responsive" alt="">
                    </a>
                </div>
                <div class="col-sm-4 portfolio-item">
                    <a href="#portfolioModal4" class="portfolio-link" data-toggle="modal">
                        <div class="caption">
                            <div class="caption-content">
                                <i class="fa fa-search-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="img/portfolio/game.png" class="img-responsive" alt="">
                    </a>
                </div>
                <div class="col-sm-4 portfolio-item">
                    <a href="#portfolioModal5" class="portfolio-link" data-toggle="modal">
                        <div class="caption">
                            <div class="caption-content">
                                <i class="fa fa-search-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="img/portfolio/safe.png" class="img-responsive" alt="">
                    </a>
                </div>
                <div class="col-sm-4 portfolio-item">
                    <a href="#portfolioModal6" class="portfolio-link" data-toggle="modal">
                        <div class="caption">
                            <div class="caption-content">
                                <i class="fa fa-search-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="img/portfolio/submarine.png" class="img-responsive" alt="">
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="success" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>About</h2>
                    <hr class="star-light">
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p>IceNSpice is one of the world's leading Nutrition, Health and Wellness companies. Our mission is to provide consumers with the best tasting, most nutritious choices in a wide range of food and beverage categories and eating occasions, from morning to night.

The Company was founded in 1958 in Mumbai,India, where our headquarters are still located today. We employ over 2,80,000 people and have factories or 
operations in almost every country in the world. IceNSpice sales for 2014 were INR 108 bn.
</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>Contact Us</h2>
                    <hr class="star-primary">
                </div>
            </div>
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                    <!-- To configure the contact form  address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
                    <!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
                    <form name="sentMessage" id="contactForm" novalidate>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <label>Name</label>
                                <input type="text" class="form-control" placeholder="Name" id="name" required data-validation-required-message="Please enter your name.">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <label>Phone Number</label>
                                <input type="tel" class="form-control" placeholder="Phone Number" id="phone" required data-validation-required-message="Please enter your phone number.">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
						<div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <label>Suggestions</label>
                                <textarea rows="5" class="form-control" placeholder="Suggestions" id="Suggestions" required data-validation-required-message="Please enter a message."></textarea>
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <label>Quality of food</label>
                                <textarea rows="5" class="form-control" placeholder="Quality of food" id="Quality of food" required data-validation-required-message="Please enter a message."></textarea>
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
						<div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <label>Speed of Service</label>
                                <textarea rows="5" class="form-control" placeholder="Speed of Service" id="Speed of Service" required data-validation-required-message="Please enter a message."></textarea>
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        <br>
                        <div id="success"></div>
                        <div class="row">
                            <div class="form-group col-xs-12">
                                <button type="submit" class="btn btn-success btn-lg">Send</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="text-center">
        <div class="footer-above">
            <div class="container">
                <div class="row">
                    <div class="footer-col col-md-4">
                        <h3>Location</h3>
                        <p>3481 Melrose Place<br>Bandra kurla complex, Mumbai 74</p>
                    </div>
                    <div class="footer-col col-md-4">
                        <h3>Around the Web</h3>
                        <ul class="list-inline">
                            <li>
                                <a href="https://www.facebook.com/" class="btn-social btn-outline"><i class="fa fa-fw fa-facebook"></i></a>
                            </li>
                            <li>
                                <a href="https://plus.google.com/" class="btn-social btn-outline"><i class="fa fa-fw fa-google-plus"></i></a>
                            </li>
                            <li>
                                <a href="https://twitter.com/" class="btn-social btn-outline"><i class="fa fa-fw fa-twitter"></i></a>
                            </li>
                            <li>
                                <a href="https://www.linkedin.com/" class="btn-social btn-outline"><i class="fa fa-fw fa-linkedin"></i></a>
                            </li>
                            <li>
                                <a href="https://dribbble.com/" class="btn-social btn-outline"><i class="fa fa-fw fa-dribbble"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-below">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        Copyright &copy; IceNSpice 2015
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
    <div class="scroll-top page-scroll visible-xs visible-sm">
        <a class="btn btn-primary" href="#page-top">
            <i class="fa fa-chevron-up"></i>
        </a>
    </div>

    <!-- Portfolio Modals -->
    <div class="portfolio-modal modal fade" id="portfolioModal1" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-content">
            <div class="close-modal" data-dismiss="modal">
                <div class="lr">
                    <div class="rl">
                    </div>
                </div>
            </div>
            <div class="container">
                        <div class="modal-body">
                            <h2>Place Orders</h2>
                            <hr class="star-primary">
                            <img src="img/portfolio/cabin.png" class="img-responsive img-centered" alt="">
                            <table style="width:100%">
                                <tr><td>
                                    <div class="simpleCart_shelfItem">
                                        <p class="item_name">Chips-1</p>
                                        <div class="item-thumb "><img src="img/portfolio/chips1a.png" style="width:300px;height:300px"></div>
                                        <input value="1" class="item_Quantity" type="text">
                                        <span class="item_price">$35.99</span>
                                        <a class="item_add" href="javascript:;"> Add to Cart </a>
                                    </div>
                                    </td>
                                    <td>
                                    <div class="simpleCart_shelfItem">
                                        <p class="item_name">Chips-2</p>
                                        <div class="item-thumb "><img src="img/portfolio/chips2.jpg" style="width:300px;height:300px"></div>
                                        <input value="1" class="item_Quantity" type="text">
                                        <span class="item_price">$35.99</span>
                                        <a class="item_add" href="javascript:;"> Add to Cart </a>
                                    </div>
                                    </td>
                                    <td>
                                    <div class="simpleCart_shelfItem">
                                        <p class="item_name">Chips-3</p>
                                        <div class="item-thumb "><img src="img/portfolio/chips3.png" style="width:300px;height:300px"></div>
                                        <input value="1" class="item_Quantity" type="text">
                                        <span class="item_price">$35.99</span>
                                        <a class="item_add" href="javascript:;"> Add to Cart </a>
                                    </div>
                                </td>
                                </tr>
                                <tr><td>
                                    <div class="simpleCart_shelfItem">
                                        <p class="item_name">Chips-4</p>
                                        <div class="item-thumb "><img src="img/portfolio/chips4.png" style="width:300px;height:300px"></div>
                                        <input value="1" class="item_Quantity" type="text">
                                        <span class="item_price">$35.99</span>
                                        <a class="item_add" href="javascript:;"> Add to Cart </a>
                                    </div>
                                </td><td>
                                    <div class="simpleCart_shelfItem">
                                        <p class="item_name">Chips-5</p>
                                        <div class="item-thumb "><img src="img/portfolio/chips5.png" style="width:300px;height:300px"></div>
                                        <input value="1" class="item_Quantity" type="text">
                                        <span class="item_price">$35.99</span>
                                        <a class="item_add" href="javascript:;"> Add to Cart </a>
                                    </div>
                                </td>
                                <td>
                                    <div class="simpleCart_shelfItem">
                                        <p class="item_name">Chips-6</p>
                                        <div class="item-thumb "><img src="img/portfolio/chips6.png" style="width:300px;height:300px"></div>
                                        <input value="1" class="item_Quantity" type="text">
                                        <span class="item_price">$35.99</span>
                                        <a class="item_add" href="javascript:;"> Add to Cart </a>
                                    </div>
                                </td></tr>
                                <tr><td>
                                    <div class="simpleCart_shelfItem">
                                        <p class="item_name">Beverage-1</p>
                                        <div class="item-thumb "><img src="img/portfolio/cb1.jpg" style="width:300px;height:300px"></div>
                                        <input value="1" class="item_Quantity" type="text">
                                        <span class="item_price">$35.99</span>
                                        <a class="item_add" href="javascript:;"> Add to Cart </a>
                                    </div>
                                </td><td>
                                    <div class="simpleCart_shelfItem">
                                        <p class="item_name">Beverage-2</p>
                                        <div class="item-thumb "><img src="img/portfolio/cb2.jpg" style="width:300px;height:300px"></div>
                                        <input value="1" class="item_Quantity" type="text">
                                        <span class="item_price">$35.99</span>
                                        <a class="item_add" href="javascript:;"> Add to Cart </a>
                                    </div>
                            </td><td>
                                    <div class="simpleCart_shelfItem">
                                        <p class="item_name">Beverage-3</p>
                                        <div class="item-thumb "><img src="img/portfolio/cb3.jpg" style="width:300px;height:300px"></div>
                                        <input value="1" class="item_Quantity" type="text">
                                        <span class="item_price">$35.99</span>
                                        <a class="item_add" href="javascript:;"> Add to Cart </a>
                                    </div>
                                </td>
                                <tr><td>
                                    <div class="simpleCart_shelfItem">
                                        <p class="item_name">Beverage-4</p>
                                        <div class="item-thumb "><img src="img/portfolio/cb4.jpg" style="width:300px;height:300px"></div>
                                        <input value="1" class="item_Quantity" type="text">
                                        <span class="item_price">$35.99</span>
                                        <a class="item_add" href="javascript:;"> Add to Cart </a>
                                    </div>
                                </td><td>
                                    <div class="simpleCart_shelfItem">
                                        <p class="item_name">Beverage-5</p>
                                        <div class="item-thumb "><img src="img/portfolio/cb5.jpg" style="width:300px;height:300px"></div>
                                        <input value="1" class="item_Quantity" type="text">
                                        <span class="item_price">$35.99</span>
                                        <a class="item_add" href="javascript:;"> Add to Cart </a>
                                    </div>
                                </td><td>
                                    <div class="simpleCart_shelfItem">
                                        <p class="item_name">Beverage-6</p>
                                        <div class="item-thumb "><img src="img/portfolio/cb6.jpg" style="width:300px;height:300px"></div>
                                        <input value="1" class="item_Quantity" type="text">
                                        <span class="item_price">$35.99</span>
                                        <a class="item_add" href="javascript:;"> Add to Cart </a>
                                    </div>
                                    </td></tr>
                            </table>
                            <h4 align="center"><a href="javascript:;" class="simpleCart_empty">Empty Cart</a></h4>
                            <span class="simpleCart_quantity"></span> items - <span class="simpleCart_total"></span>
                            <h4 align="center"><a href="javascript:;" class="simpleCart_checkout">Checkout</a></h4>
                            <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="portfolio-modal modal fade" id="portfolioModal2" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-content">
            <div class="close-modal" data-dismiss="modal">
                <div class="lr">
                    <div class="rl">
                    </div>
                </div>
            </div>
            <div class="container">
                <!--<div class="row">
                    <div class="col-lg-8 col-lg-offset-2">-->
                        <div class="modal-body">
                            <h2>Our Products</h2>
                            <hr class="star-primary">
                            <img src="img/portfolio/cake.png" class="img-responsive img-centered" alt="">
                            <table align="center">
                                <tr><td><h2 align="center">Chips</h2></td></tr>
                                <tr>
                                <td><img src="img/portfolio/chips1a.png" alt="chips1" style="width:300px;height:300px;"></td>
                                <td><img src="img/portfolio/chips2.jpg" alt="chips2" style="width:300px;height:300px;"></td>
                                <td><img src="img/portfolio/chips3.png" alt="chips3" style="width:300px;height:300px;"></td>
                                </tr>
                                <tr>
                                <td><img src="img/portfolio/chips4.png" alt="chips1" style="width:300px;height:300px;"></td>
                                <td><img src="img/portfolio/chips5.png" alt="chips2" style="width:300px;height:300px;"></td>
                                <td><img src="img/portfolio/chips6.png" alt="chips3" style="width:300px;height:300px;"></td>
                                </tr>
                                <tr><td><h2 align="center">Beverages</h2></td></tr>
                                <tr>
                                <td><img src="img/portfolio/cb1.jpg" alt="cb1" style="width:300px;height:300px;"></td>
                                <td><img src="img/portfolio/cb2.jpg" alt="cb2" style="width:300px;height:300px;"></td>
                                <td><img src="img/portfolio/cb3.jpg" alt="cb3" style="width:300px;height:300px;"></td>
                                </tr>
                                <tr>
                                <td><img src="img/portfolio/cb4.jpg" alt="cb4" style="width:300px;height:300px;"></td>
                                <td><img src="img/portfolio/cb5.jpg" alt="cb5" style="width:300px;height:300px;"></td>
                                <td><img src="img/portfolio/cb6.jpg" alt="cb6" style="width:300px;height:300px;"></td>
                                </tr>    
                                </table>
                            <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="portfolio-modal modal fade" id="portfolioModal3" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-content">
            <div class="close-modal" data-dismiss="modal">
                <div class="lr">
                    <div class="rl">
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2">
                        <div class="modal-body">
                            <h2>Customer Care</h2>
                            <hr class="star-primary">
                            <img src="img/portfolio/circus.png" class="img-responsive img-centered" alt="">
                            <p>Round the clock customer care, with well educated personnel to ensure swift and efficient redressal of all the queries of our valued customers.</p>
                            <p>Call on 1800-2648-2648</p>
                            <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="portfolio-modal modal fade" id="portfolioModal4" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-content">
            <div class="close-modal" data-dismiss="modal">
                <div class="lr">
                    <div class="rl">
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="modal-body">
                            <h2>Branches</h2>
                            <hr class="star-primary">
                            <img src="img/portfolio/game.png" class="img-responsive img-centered" alt="" height="60%" width="60%">
                            <p>For business enquiries, please call your nearest Ice N Spice office:</p>
                            <div class="row">
                            <div class="col-lg-2 col-lg-offset-1">
                                    <img src="img/flags/au.png" class="img-responsive img-centered" alt="">
                                <p><strong>Australia</strong><br>+61 450 266 295<br><small>7748 Mill Street 
Racine, AU 53402</small></p>
                            </div>
                            <div class="col-lg-2">
                                    <img src="img/flags/ca.png" class="img-responsive img-centered" alt="">
                                <p><strong>Canada</strong><br>+1 877 647 0404<br><small>1160 Valley Road 
Wilson, CA 27893</small></p>
                            </div>
                            <div class="col-lg-2">
                                    <img src="img/flags/gb.png" class="img-responsive img-centered" alt="">
                                <p><strong>United Kingdom</strong><br>+44 20 3095 4951<br><small>9920 Beechwood Drive 
Superior, GB 54880</small></p>
                            </div>
                            <div class="col-lg-2">
                                    <img src="img/flags/us.png" class="img-responsive img-centered" alt="">
                                <p><strong>United States</strong><br>+1 844 8 ZOMATO<br><small>1691 Virginia Street 
Port Charlotte, NY 33952</small></p>
                            </div>
                            <div class="col-lg-2">
                                    <img src="img/flags/bra.png" class="img-responsive img-centered" alt="">
                                <p><strong>Brazil</strong><br>+55 871 352 196<br><small>9409 Tanglewood Drive 
Brownsburg, RJ 46112</small></p>
                            </div>
                        </div>
                            <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="portfolio-modal modal fade" id="portfolioModal5" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-content">
            <div class="close-modal" data-dismiss="modal">
                <div class="lr">
                    <div class="rl">
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2">
                        <div class="modal-body">
                            <h2>Meet the owners</h2>
                            <hr class="star-primary">
                            <img src="img/portfolio/safe.png" class="img-responsive img-centered" alt="">
                            <table align="center">
                                <tr>
                                <td><img src="img/portfolio/amit.jpg" alt="amit" style="width:300px;height:300px;"></td>
                                <td><p>The CEO</p></td>
                                </tr>
                                <tr>
                                <td><img src="img/portfolio/anjaneya.jpg" alt="anjaneya" style="width:300px;height:300px;"></td>
                                <td><p> Marketing Head</p></td>
                                </tr>
                                <tr>
                                <td><img src="img/portfolio/cressida.jpg" alt="cressida" style="width:300px;height:300px;"></td>
                                <td><p> Web Designer</p></td>
                                </tr>
                                <tr>
                                <td><img src="img/portfolio/chaitali.jpg" alt="chaitali" style="width:300px;height:300px;"></td>
                                <td><p> Head of Sales</p></td>
                                </tr>
                                </table>
                            <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="portfolio-modal modal fade" id="portfolioModal6" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-content">
            <div class="close-modal" data-dismiss="modal">
                <div class="lr">
                    <div class="rl">
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2">
                        <div class="modal-body">
                            <h2>Announcements</h2>
                            <hr class="star-primary">
                            <img src="img/portfolio/submarine.png" class="img-responsive img-centered" alt="">
                            <p>June 2015:Gopal Chattopadhyay Named Chief Supply Chain Officer of IceNSpice</p>
                            <p>August 2015:IceNSpice announces opening of 3 new factories in Canada</p>
                            <p>September 2015:IceNSpice Announces $300 Million Efficiency Plan, Establishes Chicago Headquarters</p>
                            <p>October 2015:CEO launches 'Save girl child' campaign in India</p>
                            <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="js/classie.js"></script>
    <script src="js/cbpAnimatedHeader.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/freelancer.js"></script>
    <!--shopping cart-->
    <script src="simpleCart.js"></script>
        <script>
    simpleCart({
        checkout: {
        type: "PayPal",
        email: "you@yours.com"
                    }
                });
        </script>


</body>

</html>
