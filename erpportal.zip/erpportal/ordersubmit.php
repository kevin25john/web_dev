<?php 
    session_start();
    require 'database-config.php';
    $role = $_SESSION['sess_userrole'];
$order=$_POST['item'];
$quantity=$_POST['quantity'];
echo $order;
echo $quantity;
$q = "INSERT INTO `Orders`(`Product`, `Quantity`) VALUES ('$order','$quantity')";

	$query = $dbh->prepare($q);

	$query->execute(array('Product' => $order, 'Quantity' => $quantity));


   if(!isset($_SESSION['sess_username']) && $role!="admin"){
      header('Location: index.php?err=2');
    }
 header('Location: adminhome.php');


?>