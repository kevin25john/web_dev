<?php 
    session_start();
    $role = $_SESSION['sess_userrole'];
    if(!isset($_SESSION['sess_username']) && $role!="admin"){
      header('Location: index.php?err=2');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IceNSpice</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
        <link href="css/freelancer.css"  rel="stylesheet">
<!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">
    </head>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  <body>
    
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">Home</a>
        </div>

        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="#"><?php echo $_SESSION['username'];?></a></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </div>
      </div>
    </div>
    <br><br><br><br>
    <div class="container homepage">
      <div class="row">
         <div class="col-md-3"></div>
            <div class="col-md-6 welcome-page">
              <h2>Enter your order.</h2>
            </div>
          <div class="col-md-3"></div>
        </div>
    </div><div class="container homepage">
      <div class="row">
         <div class="col-md-3"></div>
            <div class="col-md-6 welcome-page">
                <form method="POST" action="ordersubmit.php" class="form-signin col-md-8 col-md-offset-2" role="form">  
                                  <select name="item" id="item">
                                        <option value="potatoes">Potatoes(100 kg)</option>
                                        <option value="salt">Salt(100 kg)</option>
                                        <option value="pepper">Pepper(100 kg)</option>
                                        <option value="jalapeno">Jalapeno(50 kg)</option>
                                        <option value="bluecuraco">Blue curaco(50 kg)</option>
                                        <option value="lemons">Lemons(50 kg)</option>
                                        <option value="chillies">Chillies(100 kg)</option>
                                        <option value="oregano">Oregano(100 kg)</option>
                                        <option value="coriander">Coriander(50 kg)</option>
                                        <option value="mango">Mango(100 kg)</option>
                                    </select><br/>
                                  <input type="number" id="quantity" name="quantity" class="form-control" placeholder="Quantity" required><br/>
                                  <button class="btn btn-lg btn-primary btn-block" type="submit">Submit</button>
                             </form>
            </div>
          <div class="col-md-3"></div>
        </div>
    </div>    
<!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="js/classie.js"></script>
    <script src="js/cbpAnimatedHeader.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/freelancer.js"></script>
    <!--shopping cart-->
    <script src="simpleCart.js"></script>
        <script>
    simpleCart({
        checkout: {
        type: "PayPal",
        email: "you@yours.com"
                    }
                });
        </script>
    </body>
</html>
