<?php 
	require 'database-config.php';

	session_start();

	$username = "";
	$password = "";
	
	if(isset($_POST['username'])){
		$username = $_POST['username'];
	}
	if (isset($_POST['password'])) {
		$password = $_POST['password'];

	}
	
	echo $username ." : ".$password;

	$q = "SELECT * FROM login_admin WHERE username='$username' AND password='$password'";

	$query = $dbh->prepare($q);

	$query->execute(array('username' => $username, 'password' => $password));


	if($query->rowCount() == 0){
		header('Location: index.php?err=1');
	}else{

		$row = $query->fetch(PDO::FETCH_ASSOC);

		session_regenerate_id();
		$_SESSION['username']=$username;
				
        $_SESSION['sess_userrole'] = $row['role'];
echo  $_SESSION['sess_userrole'];

		if( $_SESSION['sess_userrole'] == "admin"){
			header('Location: adminhome.php');
		}
        else if($_SESSION['sess_userrole'] == "supplier"){
			header('Location: supplierhome.php');
		}
        else{
			header('Location: userhome.php');
		}

		
	}


?>